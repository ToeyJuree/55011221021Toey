//
//  ViewController.swift
//  Tip
//
//  Created by iStudents on 2/6/15.
//  Copyright (c) 2015 iStudents. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    @IBOutlet weak var onelabel: UILabel!
    
    @IBOutlet weak var twolabel: UILabel!
    
    @IBOutlet weak var threelabel: UILabel!
    
    var n1 = 0
    var n2 = 0
    var n3 = 0
    
    @IBAction func onebutton(sender: AnyObject) {
    
        n1 = n1 + 1
        onelabel.text = String(n1)
    }
    
    

    @IBAction func twobutton(sender: AnyObject) {
        
        n2 = n2 + 2
        twolabel.text = String(n2)
    }
    
    
    @IBAction func threebutton(sender: AnyObject) {
        
        n3 = n3 + 3
        threelabel.text = String(n3)
    }
    
    @IBAction func Resetbutton(sender: AnyObject) {
        
        onelabel.text = "0"
        twolabel.text = "0"
        threelabel.text = "0"
        n1 = 0
        n2 = 0
        n3 = 0
    }
}

