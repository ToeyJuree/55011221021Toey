//
//  ViewController.swift
//  Exam1_55011221021
//
//  Created by iStudents on 3/13/15.
//  Copyright (c) 2015 iStudents. All rights reserved.
//

import UIKit


class ViewController: UIViewController {
    

   
    override func viewDidLoad() {
        super.viewDidLoad()
       
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    
    @IBOutlet weak var subject: UILabel!
    
    @IBOutlet weak var Textfield1: UITextField!

    @IBOutlet weak var totalmidterm: UILabel!
    
    @IBOutlet weak var Textfield2: UITextField!
    @IBOutlet weak var totalmidterm2: UILabel!
    @IBOutlet weak var Textfield3: UITextField!
    
    @IBOutlet weak var total1: UILabel!
    
    @IBOutlet weak var total2: UITextField!
    
    @IBOutlet weak var total3: UILabel!
    
    @IBOutlet weak var total4: UITextField!
    
    @IBOutlet weak var totalFinal: UILabel!
    @IBOutlet weak var totalFinal1: UITextField!
    @IBOutlet weak var totalFinal2: UILabel!
    
    @IBOutlet weak var totalFinal3: UITextField!
    
    
    @IBAction func calculate(sender: AnyObject) {
        
        
        
      /*  var name = String (subject.text as NSString).doubleValue)
       var m1 = Int (totalmidterm.text as NSString).integerValue)
        var m2 = Double (totalmidterm2.text as NSString).doubleValue)
        var m3 = Int (total1.text as NSString).integerValue)
        var m4 = Double (total3.text as NSString).doubleValue)
        var m5 = Int (totalFinal.text as NSString).integerValue)
        var m6 = Double (totalFinal2.text as NSString).doubleValue)
        var gread:String = " "
        var mm = m1 + m3 + m5
        var mm2 = m2 + m4 + m6*/
    }

        
    
        
        

                
        
        
    }


