//
//  balloon.swift
//  newAppProject
//
//  Created by iStudents on 3/6/15.
//  Copyright (c) 2015 iStudents. All rights reserved.
//

import Foundation
import UIKit

struct balloon {
    var facImage: UIImage
    var facname: String
    
    init (bImage: UIImage,bName: String){
        self.facImage=bImage
        self.facname=bName
        
    }
    
}
